
let questions = [
    {
    numb: 1,
    question: "What genres well perfer?",
    options: [
      "Action",
      "Crime",
      "Horror",
      "Comedies",
      "Documentary"
    ]
  },
    {
    numb: 2,
    question: "What sub-genres well perfer?",
    
    options: [
      "Crime Thriller",
      "Disaster Thriller",
      "Psychological Thriller",
      "Techno Thriller"
    ]
  },
    {
    numb: 3,
    question: "Select the language",
   
    options: [
      "Hindi",
      "English",
      "Tamil",
      "Japanese"
    ]
  },
    ,
];